export default {
  modes: {
    default: "dev",
    dev: () => ({ manager: "store" }),
  },
  packages: {
    "@test/simple-lib": { version: "1.0.0" },
    "@test/lib-with-deps": { version: "1.0.0" },
    "@test/synthetic-sst": { version: "1.0.0", synthetic: true },
    "@test/cli-tool": { version: "1.0.0", dev: true },
  },
};
