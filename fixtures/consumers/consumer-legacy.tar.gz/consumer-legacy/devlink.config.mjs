export default {
  packages: {
    "@test/simple-lib": { version: { dev: "1.0.0" } },
    "@test/lib-with-deps": { version: { dev: "1.0.0" } },
  },
  dev: () => ({ manager: "store" }),
};
